"""Report generators."""
