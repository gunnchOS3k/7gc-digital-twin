"""Geospatial and scene ingest."""
