"""Diagram data export."""
